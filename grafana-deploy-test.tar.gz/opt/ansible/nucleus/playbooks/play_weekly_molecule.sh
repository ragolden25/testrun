#!/bin/bash
# play_weekly_molecule.sh - run the Grafana and Guacamole Molecule scenarios after the weekly image builds.
#
# Save as /opt/ansible/nucleus/playbooks/play_weekly_molecule.sh (owner ansible, chmod 755), then as ansible:
# play_weekly_molecule.sh --install-cron adds the Thursday 04:00 crontab line (idempotent)
# play_weekly_molecule.sh run it now (waits if the weekly builds are still running)
#
# Runs, in order:
#   Grafana:   grafana12 (role config) -> grafana12-image nucleus -> grafana12-image ccop
#              -> grafana12-deploy deploy+verify (production role on std1, nucleus images)
#   Guacamole: guac16 ccop deploy+verify (functional images, relaxed compose)
#              -> guac16 nucleus deploy -> guac16 nucleus verify (hardened, production compose).
#              nucleus runs last so the guac VM is left on the hardened deployment.
# Reports each to the pipeline dashboard: emit_event.sh check molecule-<name> success|fail "" 604800
# Also writes $TEXTFILE_DIR/pipeline_weekly_molecule.prom for the Nucleus Pipelines Status dashboard,
# including pipeline_weekly_molecule_failure_info{stack,test,task,reason,log} for every test that failed
# (the failed task, its error and its log, read from the scenario log) or was not tested (the reason).
# An image class with no tarball built in the last 24 h is reported as NOT TESTED (status 2), not as a failure.
# Housekeeping: logs older than LOG_DAYS (28) are deleted at the start of every run, and a test is
# reported NOT TESTED instead of starting when /opt/ansible/molecule has less than MIN_FREE_GB (50) free.
# Exit status 0 only if every scenario that ran passed.

set -u
[ "$(id -un)" = ansible ] || { echo "run play_weekly_molecule.sh as ansible, not $(id -un)"; exit 1; }
RUN_DIR="${RUN_DIR:-/opt/ansible/molecule}"
LOG="${LOG:-/opt/ansible/logs/weekly-molecule.log}"
EMIT="${EMIT:-/usr/local/bin/emit_event.sh}"
TEXTFILE_DIR="${TEXTFILE_DIR:-/var/lib/node_exporter/textfile}"
CLASSES="${MOL_CLASSES:-nucleus ccop}" # image classes to test
IMG_DIR="${IMG_DIR:-/opt/ansible/files/grafana/weekly}" # weekly tree: <week#>/images/<class>-grafana-<ver>.tar.gz
GUAC_IMG_DIR="${GUAC_IMG_DIR:-/opt/ansible/files/avocado/weekly}" # <week#>/images/<class>-guacamole-<ver>.tar.gz
WAIT_MAX="${WAIT_MAX:-10800}" # give up waiting for the builds after 3 h
MOL_FS="${MOL_FS:-/opt/ansible/molecule}"        # Molecule's partition (scratch, cache, logs)
MIN_FREE_GB="${MIN_FREE_GB:-50}"                 # don't start a test with less free than this
IMG_MAX_AGE_MIN="${IMG_MAX_AGE_MIN:-1440}"       # test only images built this recently (minutes); raise it for a manual run later in the week
LOG_DAYS="${LOG_DAYS:-28}"                       # keep Molecule logs about 4 weeks, like the weekly builds
CRON_LINE='0 4 * * 4 /opt/ansible/nucleus/playbooks/play_weekly_molecule.sh >> /opt/ansible/logs/weekly-molecule-cron.log 2>&1'

if [ "${1:-}" = "--install-cron" ]; then
  if crontab -l 2>/dev/null | grep -qF 'play_weekly_molecule.sh'; then
    echo "crontab already has play_weekly_molecule.sh - left alone"
  else
    crontab -l > "$HOME/crontab.bak-$(date +%Y%m%d-%H%M)" 2>/dev/null
    { crontab -l 2>/dev/null; printf '\n# weekly molecule tests (after the weekly image builds)\n%s\n' "$CRON_LINE"; } | crontab - \
      && echo "added: $CRON_LINE"
  fi
  exit 0
fi

mkdir -p "$(dirname "$LOG")"
exec >>"$LOG" 2>&1
log() { echo "$(date -Iseconds) $*"; }

# One run at a time (a manual run and the cron run must not overlap).
exec 9>/tmp/weekly-molecule.lock
flock -n 9 || { log "another weekly molecule run is active - exiting"; exit 1; }

log "=== weekly molecule start ==="

# Housekeeping: drop old Molecule logs (scenario logs and this script's own logs).
find "$MOL_FS/logs" -maxdepth 1 -type f -name '*.log' -mtime +"$LOG_DAYS" -print -delete 2>/dev/null \
  | sed 's/^/deleted old log: /'
find "$(dirname "$LOG")" -maxdepth 1 -type f -name 'weekly-molecule*.log' -mtime +"$LOG_DAYS" -print -delete 2>/dev/null \
  | sed 's/^/deleted old log: /'

# Wait for the weekly builds to finish (they own the Docker daemon and the scratch dirs).
waited=0
BUILDS_RE="${BUILDS_RE:-^(/bin/|/usr/bin/)?(ba)?sh( -c)? +/opt/ansible/nucleus/playbooks/play_weekly_builds\.sh}"
while pgrep -f "$BUILDS_RE" >/dev/null 2>&1; do
  [ "$waited" -ge "$WAIT_MAX" ] && { log "weekly builds still running after ${WAIT_MAX}s - giving up"; "$EMIT" check molecule-weekly fail "" 604800 >/dev/null 2>&1 || true; exit 1; }
  [ $((waited % 600)) -eq 0 ] && log "weekly builds still running - waiting"
  sleep 60; waited=$((waited + 60))
done

rc=0
METRICS=""
FAILS=""
free_gb() { df -P -BG "$MOL_FS" 2>/dev/null | awk 'NR==2 {gsub("G","",$4); print $4+0}'; }

# failure_info <stack> <scenario> <since epoch> - which task failed, why, and in which log, from the
# newest scenario log written since <since>. Adds one pipeline_weekly_molecule_failure_info line to FAILS.
esc() { printf '%s' "$1" | tr -d '\r' | tr '\n\t' '  ' | sed 's/\\/\\\\/g; s/"/\\"/g' | cut -c1-220; }
failure_info() {
  local stack=$1 scen=$2 since=$3 f logf="" newest="" task="" why=""
  for f in $(ls -t "$MOL_FS"/logs/*.log 2>/dev/null); do
    [ "$(stat -c %Y "$f")" -ge "$since" ] || break
    [ -n "$newest" ] || newest=$f
    if sed 's/\x1b\[[0-9;]*m//g' "$f" | grep -q '^fatal: '; then logf=$f; break; fi
  done
  if [ -n "$logf" ]; then
    # first fatal: that is not followed by "...ignoring"; its task is the TASK [...] line before it
    read -r task why < <(sed 's/\x1b\[[0-9;]*m//g' "$logf" | awk '
      /^TASK \[/ { t = $0; sub(/^TASK \[/, "", t); sub(/\] \**$/, "", t); sub(/^\/opt\/ansible\/nucleus\/roles\//, "", t) }
      pend && /^\.\.\.ignoring/ { pend = 0; next }
      pend { print ptask "\t" pmsg; done = 1; exit }
      /^fatal: / { pend = 1; ptask = t; m = $0
                   if (match(m, /"msg": "[^"]*/)) pmsg = substr(m, RSTART + 8, RLENGTH - 8); else pmsg = "see log"
                   gsub(/\t/, " ", ptask) }
      END { if (pend && !done) print ptask "\t" pmsg }' | tr '\t' '\001' | { IFS=$'\001' read -r a b; printf '%s %s\n' "$(printf '%s' "$a" | tr ' ' '\002')" "$b"; })
    task=$(printf '%s' "$task" | tr '\002' ' ')
  elif [ -n "$newest" ]; then
    logf=$newest; task="no failed task in the log"; why="stopped early or timed out - see log"
  else
    logf="$MOL_FS/logs"; task="no log written"; why="the test did not start - see the runner log $LOG"
  fi
  FAILS="${FAILS}$(printf 'pipeline_weekly_molecule_failure_info{stack="%s",test="%s",task="%s",reason="%s",log="%s"} 1' \
    "$stack" "$scen" "$(esc "$task")" "$(esc "$why")" "$(esc "$logf")")
"
}

LAST_OK=0
run() { # run <stack> <event-name> <scenario> <command...>
  local stack=$1 name=$2 scen=$3; shift 3
  local t0 t1 ok=0 lbl free
  free=$(free_gb)
  if [ "${free:-0}" -lt "$MIN_FREE_GB" ]; then
    LAST_OK=0
    skip "$stack" "$name" "$scen" "only ${free:-?} GB free on $MOL_FS (need $MIN_FREE_GB)"
    return
  fi
  t0=$(date +%s); log "--- $name: start ---"
  if "$@"; then
    ok=1; log "--- $name: PASSED ---"; "$EMIT" check "molecule-$name" success "" 604800 >/dev/null 2>&1 || true
  else
    log "--- $name: FAILED (see /opt/ansible/molecule/logs/) ---"; "$EMIT" check "molecule-$name" fail "" 604800 >/dev/null 2>&1 || true
    rc=1
    failure_info "$stack" "$scen" "$t0"
  fi
  t1=$(date +%s); LAST_OK=$ok
  lbl="stack=\"$stack\",test=\"$scen\""
  METRICS="$METRICS$(printf 'pipeline_weekly_molecule_status{%s} %s\npipeline_weekly_molecule_timestamp_seconds{%s} %s\npipeline_weekly_molecule_duration_seconds{%s} %s\n' "$lbl" "$ok" "$lbl" "$t1" "$lbl" "$((t1 - t0))")
"
}

skip() { # skip <stack> <event-name> <scenario> <reason> - status 2
  local stack=$1 name=$2 scen=$3 why=$4 t1 lbl
  t1=$(date +%s); log "--- $name: NOT TESTED ($why) ---"
  lbl="stack=\"$stack\",test=\"$scen\""
  METRICS="$METRICS$(printf 'pipeline_weekly_molecule_status{%s} 2\npipeline_weekly_molecule_timestamp_seconds{%s} %s\npipeline_weekly_molecule_duration_seconds{%s} 0\n' "$lbl" "$lbl" "$t1" "$lbl")
"
  FAILS="${FAILS}$(printf 'pipeline_weekly_molecule_failure_info{%s,task="not tested",reason="%s",log=""} 1' "$lbl" "$(esc "$why")")
"
}

fresh() { # fresh <weekly dir> <class>-<component> - a tarball built in the last IMG_MAX_AGE_MIN minutes exists
  [ -n "$(find "$1" -mindepth 3 -maxdepth 3 -path "*/images/$2-*.tar.gz" -mmin -"$IMG_MAX_AGE_MIN" 2>/dev/null)" ]
}

# ---- Grafana stack --------------------------------------------------------------
run grafana grafana12 role-config "$RUN_DIR/run-grafana12.sh"
for c in $CLASSES; do
  if fresh "$IMG_DIR" "$c-grafana"; then
    run grafana "grafana12-image-$c" "image-$c" "$RUN_DIR/run-grafana12-image.sh" "$c"
  else
    skip grafana "grafana12-image-$c" "image-$c" "no image built in the last 24h under $IMG_DIR/*/images"
  fi
done
# Deployed on std1 = the production role deployed this week's nucleus images on std1 (signature check,
# firewall, compose, wipe-and-redeploy of /var/lib/containers) and the running stack passed its checks.
grafana_deploy() { "$RUN_DIR/run-grafana12-deploy.sh" deploy && "$RUN_DIR/run-grafana12-deploy.sh" verify; }
if fresh "$IMG_DIR" "nucleus-grafana"; then
  run grafana grafana12-deploy deployment grafana_deploy
else
  skip grafana grafana12-deploy deployment "no nucleus image built in the last 24h under $IMG_DIR/*/images"
fi

# ---- Guacamole stack ------------------------------------------------------------
# ccop images     = the role deployed the weekly ccop images (relaxed compose) and they passed the checks.
# Deployment role = the role deployed the weekly nucleus images cleanly on the guac VM.
# nucleus images  = the deployed nucleus stack passed its checks (only runs if that deploy worked).
guac_ccop() { "$RUN_DIR/run-guac16.sh" deploy ccop && "$RUN_DIR/run-guac16.sh" verify ccop; }
if fresh "$GUAC_IMG_DIR" "ccop-guacamole"; then
  run guacamole guac16-ccop image-ccop guac_ccop
else
  skip guacamole guac16-ccop image-ccop "no ccop image built in the last 24h under $GUAC_IMG_DIR/*/images"
fi
if fresh "$GUAC_IMG_DIR" "nucleus-guacamole"; then
  run guacamole guac16-deploy role-config "$RUN_DIR/run-guac16.sh" deploy nucleus
  if [ "$LAST_OK" -eq 1 ]; then
    run guacamole guac16-verify image-nucleus "$RUN_DIR/run-guac16.sh" verify nucleus
  else
    skip guacamole guac16-verify image-nucleus "deployment failed, nothing to check"
  fi
else
  skip guacamole guac16-deploy role-config "no nucleus image built in the last 24h under $GUAC_IMG_DIR/*/images"
  skip guacamole guac16-verify image-nucleus "no nucleus image built in the last 24h under $GUAC_IMG_DIR/*/images"
fi

# Publish to the dashboard through node_exporter's textfile collector (same place the weekly build/CIS metrics go).
if [ -d "$TEXTFILE_DIR" ] && [ -w "$TEXTFILE_DIR" ]; then
  tmp=$(mktemp "$TEXTFILE_DIR/.pipeline_weekly_molecule.XXXXXX")
  {
    echo '# HELP pipeline_weekly_molecule_status Weekly Molecule test: 1 passed, 0 failed, 2 not tested.'
    echo '# TYPE pipeline_weekly_molecule_status gauge'
    echo '# HELP pipeline_weekly_molecule_timestamp_seconds Unix time this Molecule scenario finished.'
    echo '# TYPE pipeline_weekly_molecule_timestamp_seconds gauge'
    echo '# HELP pipeline_weekly_molecule_duration_seconds Run time of this Molecule scenario.'
    echo '# TYPE pipeline_weekly_molecule_duration_seconds gauge'
    printf '%s' "$METRICS" | sort -s -t'{' -k1,1
    echo '# HELP pipeline_weekly_molecule_failure_info A test that failed (task, reason, log) or was not tested (reason). Absent when it passed.'
    echo '# TYPE pipeline_weekly_molecule_failure_info gauge'
    printf '%s' "$FAILS"
  } > "$tmp" && chmod 0644 "$tmp" && mv -f "$tmp" "$TEXTFILE_DIR/pipeline_weekly_molecule.prom" \
    && log "metrics written to $TEXTFILE_DIR/pipeline_weekly_molecule.prom"
else
  log "WARNING: $TEXTFILE_DIR missing or not writable by $(id -un) - no metrics written (dashboard events were still sent)"
fi

log "=== weekly molecule done (rc=$rc) ==="
exit $rc
