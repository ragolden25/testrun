# quarterly_common

Shared task library behind every `quarterly_build_<component>` role. One run builds one
component's ccop (functional) and nucleus (hardened) images for the quarter.

Steps (`tasks/main.yml`): detect_version -> build -> save_deliver -> scan -> sign -> finish.
If any step fails, `fallback.yml` releases the component's last good images instead: the previous
quarter's nucleus (and ccop) tarballs, their signatures (verified again) and their scan results are
copied into this quarter. One broken component never stops the stack's release.
`finish` always runs: adds the component to `quarterly_results` (used by the stack's
`stack_finish.yml` for versions.env and docker-compose.yml) and reports to the dashboard
(`emit_event.sh quarterly <component> success|fail <version>`).

Input: the `quarterly_component` dictionary defined in each `quarterly_build_<component>` role,
plus the `quarter` / `previous_quarter` facts from the stack's `stack_prepare.yml`.
Scans: on by default; `-e quarterly_scans=false` builds without them (replaces main-no-scans.yml).
