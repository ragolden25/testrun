#!/bin/bash
# run-grafana12-deploy.sh deploy|verify - the grafana12-deploy Molecule scenario in two steps:
#   deploy  prepare the test artifact folder (this week's nucleus images, signatures, compose), then run
#           the whole configure_grafana_stack role on std1, exactly as production does
#   verify  check the deployed stack on std1, then always clean up (scratch folder + Molecule state)
# A failed deploy cleans up too. Each run's CIS Docker Benchmark report is kept in
# /opt/ansible/molecule/reports/cis/ (28 days) before the test folder is removed. Nucleus only: this proves what production deploys.
# Logs go to /opt/ansible/molecule/logs/grafana12-deploy-<step>-<date>.log
STEP="${1:-}"
case "$STEP" in deploy|verify) ;; *) echo "usage: $0 deploy|verify"; exit 2 ;; esac

source /opt/ansible/molecule/venv/bin/activate
export XDG_CACHE_HOME=/opt/ansible/molecule/cache
SCR=/opt/ansible/molecule/scratch/grafana-deploy
ROLE=/opt/ansible/nucleus/roles/configure_grafana_stack
LOG=/opt/ansible/molecule/logs/grafana12-deploy-$STEP-$(date +%F-%H%M).log
mkdir -p "$(dirname "$LOG")"

keep_cis() { # keep this run's CIS Docker Benchmark report(s) before the test folder is removed
  local d=/opt/ansible/molecule/reports/cis f
  mkdir -p "$d"
  for f in "$SCR"/artifact/provenance/*/docker_cis_report-*.csv; do
    [ -f "$f" ] && cp -p "$f" "$d/grafana12-deploy-$(basename "$f")"
  done
  find "$d" -name "*.csv" -mtime +28 -delete 2>/dev/null
}

cleanup() {
  keep_cis
  rm -rf "$SCR"
  ( cd "$ROLE" && molecule reset -s grafana12-deploy >/dev/null 2>&1 )
  true
}

cd "$ROLE" || exit 1
if [ "$STEP" = deploy ]; then
  cleanup                                  # start from nothing left by an earlier run
  trap 'rc=$?; [ $rc -ne 0 ] && cleanup' EXIT
  timeout --kill-after=120 ${MOL_TIMEOUT:-3600} molecule converge -s grafana12-deploy 2>&1 | tee "$LOG"
  rc=${PIPESTATUS[0]}
else
  trap cleanup EXIT
  timeout --kill-after=120 ${MOL_TIMEOUT:-3600} molecule verify -s grafana12-deploy 2>&1 | tee "$LOG"
  rc=${PIPESTATUS[0]}
fi
echo "log: $LOG (exit $rc)"
exit $rc
